import { Component } from '@angular/core';
import { ProductosListaComponent } from './components/productos-lista/productos-lista.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ProductosListaComponent],
  templateUrl: './app.component.html'
})
export class AppComponent {}
